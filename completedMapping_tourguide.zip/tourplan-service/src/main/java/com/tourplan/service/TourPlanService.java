package com.tourplan.service;

import org.springframework.http.ResponseEntity;

import com.tourplan.dto.HelperDTO;
import com.tourplan.dto.TourDetailsDTO;
import com.tourplan.dto.TourPlanResponseDTO;
import com.tourplan.dto.TourRequest;

public interface TourPlanService {

//	ResponseEntity<HelperDTO> getTourDetails(Integer tourId);

	ResponseEntity<String> updateTour(Integer tourId, TourDetailsDTO tourDetailsDto)throws Throwable ;

	ResponseEntity<String> deleteTour(Integer tourId);

	ResponseEntity<String> createPlan(Integer userId, TourDetailsDTO tourDetailsDto);

	ResponseEntity<TourPlanResponseDTO> getTourPlan(Integer tourId)  throws Throwable;

}
