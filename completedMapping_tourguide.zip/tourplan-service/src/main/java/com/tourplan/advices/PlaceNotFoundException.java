package com.tourplan.advices;

public class PlaceNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public PlaceNotFoundException(String string) {
		super(string);
	}
}
