package com.tourplan.advices;

public class TourNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public TourNotFoundException(String string) {
		super(string);
	}
}
