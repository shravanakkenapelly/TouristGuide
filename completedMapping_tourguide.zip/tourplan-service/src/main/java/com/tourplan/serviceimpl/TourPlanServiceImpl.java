package com.tourplan.serviceimpl;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.tourplan.advices.PlaceNotFoundException;
import com.tourplan.advices.TourNotFoundException;
import com.tourplan.advices.UserNotFoundException;
import com.tourplan.dto.GenerateDate;
import com.tourplan.dto.PlaceDTO;
import com.tourplan.dto.TourDatesPlacesDTO;
import com.tourplan.dto.TourDetailsDTO;
import com.tourplan.dto.TourPlanResponseDTO;
import com.tourplan.dto.UserDTO;
import com.tourplan.entity.Tour;
import com.tourplan.entity.TourDatesPlaces;
import com.tourplan.openfeign.PlaceClient;
import com.tourplan.openfeign.UserClient;
import com.tourplan.repository.TourDatesPlacesRepository;
import com.tourplan.repository.TourRepository;
import com.tourplan.service.TourPlanService;

@Service
public class TourPlanServiceImpl implements TourPlanService {

	@Autowired
	PlaceClient placeClients;

	@Autowired
	UserClient userClients;

	@Autowired
	TourRepository tourPlanRepo;

	@Autowired
	TourDatesPlacesRepository DatesPlaceRepo;

	@Override
	public ResponseEntity<TourPlanResponseDTO> getTourPlan(Integer tourId) throws Throwable {
	    Optional<Tour> tourOptional = tourPlanRepo.findById(tourId);

	    if (tourOptional.isPresent()) {
	        Tour tour = tourOptional.get();

	        // Fetch TourDatesPlaces for the given tourId
	        List<TourDatesPlaces> tourDatesPlacesList = DatesPlaceRepo.findByTourId(tourId);

	        // Create TourPlanResponseDTO to hold the response
	        TourPlanResponseDTO responseDTO = new TourPlanResponseDTO();
	        responseDTO.setTourId(tour.getTourId());

	        // Fetch UserDTO using Feign Client
	        ResponseEntity<UserDTO> userDTOResponse = userClients.getUserById(tour.getUserId());

	        // Check if the userDTO response is successful
	        if (userDTOResponse.getStatusCode() == HttpStatus.OK) {
	            responseDTO.setUserdto(userDTOResponse.getBody());
	        } else {
	            throw new UserNotFoundException("User details not found");
	        }

	        // Fetch List of PlaceDTO's from place service using Feign Client
	        List<Integer> placeIds = tourDatesPlacesList.stream().map(TourDatesPlaces::getPlaceId).collect(Collectors.toList());
	        ResponseEntity<List<PlaceDTO>> placeDTOResponse = placeClients.getListOfPlaceDTOByPlaceId(placeIds);

	        // Check if the placeDTO response is successful
	        if (placeDTOResponse.getStatusCode() == HttpStatus.OK) {
	            List<PlaceDTO> list2 = placeDTOResponse.getBody();

	            // Convert TourDatesPlaces entities to DTOs
	            List<TourDatesPlacesDTO> tourDatesPlacesDTOList = new LinkedList<>();
	            for (TourDatesPlaces tourDatesPlaces : tourDatesPlacesList) {
	                TourDatesPlacesDTO dto = new TourDatesPlacesDTO();
	                dto.setPlanId(tourDatesPlaces.getPlanId());
	                dto.setTourDate(tourDatesPlaces.getTourDate());

	                // Find the corresponding PlaceDTO for the current TourDatesPlaces
	                Optional<PlaceDTO> placeDTOOptional = list2.stream()
	                        .filter(placeDTO -> placeDTO.getPlaceId().equals(tourDatesPlaces.getPlaceId())).findFirst();

	                // Set the PlaceDTO if found
	                if (placeDTOOptional.isPresent()) {
	                    dto.setPlaceDto(placeDTOOptional.get());
	                } else {
	                    throw new PlaceNotFoundException("Place details not found");
	                }

	                tourDatesPlacesDTOList.add(dto);
	            }

	            responseDTO.setTourDatesPlacesList(tourDatesPlacesDTOList);

	            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	        } else {
	            throw new PlaceNotFoundException("Place details not found");
	        }
	    } else {
	        throw new TourNotFoundException("Tour Details not found");
	    }
	}


	@Override
	public ResponseEntity<String> updateTour(Integer tourId, TourDetailsDTO tourDetailsDto) throws Throwable {

		Optional<Tour> tourOptional = tourPlanRepo.findById(tourId);

		if (tourOptional.isEmpty()) {
			throw new TourNotFoundException("Tour Details not found");
		}

		Tour existingTour = tourOptional.get();

		// Update TourDatesPlaces based on the provided details
		List<TourDatesPlaces> existingTourDatesPlaces = DatesPlaceRepo.findByTourId(tourId);

//		Generate List of dates between start and end dates
		LocalDate startDate = LocalDate.parse(tourDetailsDto.getStartDate());
		LocalDate endDate = LocalDate.parse(tourDetailsDto.getEndDate());
		List<String> tourDates = GenerateDate.generateDatesBetween(startDate, endDate);

		// Assuming the size of existingTourDatesPlaces is the same as the size of
		// placeIds
		List<Integer> placeIds = tourDetailsDto.getPlaceIds();

		// Check if existingTourDatesPlaces size matches placeIds size
		if (existingTourDatesPlaces.size() != placeIds.size()) {
			throw new IllegalArgumentException("Mismatched details for existing Dates or Places ");
		}

		for (int i = 0; i < existingTourDatesPlaces.size(); i++) {
			String tourDate = tourDates.get(i);
			TourDatesPlaces tourDatesPlaces = existingTourDatesPlaces.get(i);
			Integer selectedPlaceId = placeIds.get(i);

			// Update TourDatesPlaces details
			tourDatesPlaces.setPlaceId(selectedPlaceId);
			tourDatesPlaces.setTourDate(tourDate);

			// Save the updated TourDatesPlaces
			DatesPlaceRepo.save(tourDatesPlaces);
		}
		return new ResponseEntity<>("Details Updated", HttpStatus.OK);
	}

	@Override
	public ResponseEntity<String> deleteTour(Integer tourId) {
		// Fetch TourDatesPlaces entities with the given tourId
		List<TourDatesPlaces> tourDatesPlacesList = DatesPlaceRepo.findByTourId(tourId);

		if (tourDatesPlacesList.isEmpty()) {
			// Handle the case where there are no TourDatesPlaces for the given tourId
			return new ResponseEntity<>("Tour not found", HttpStatus.NOT_FOUND);
		}

		// Delete the TourDatesPlaces entities
		DatesPlaceRepo.deleteAll(tourDatesPlacesList);

		// Delete the Tour entity
		if (tourPlanRepo.existsById(tourId)) {
			tourPlanRepo.deleteById(tourId);
			return new ResponseEntity<>("Tour Deleted", HttpStatus.OK);
		} else {
			// Handle the case where the Tour entity with the given ID is not found
			return new ResponseEntity<>("Tour not found", HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public ResponseEntity<String> createPlan(Integer userId, TourDetailsDTO tourDetailsDto) {

//		Using Feign clients to get userId from user-microservice
		Integer userIdForClient = userClients.getUserForClient(userId);

//		Create tourDetails entity
		Tour tourDetails = new Tour();
		tourDetails.setUserId(userIdForClient);

		tourPlanRepo.save(tourDetails);

//		Generate List of dates between start and end dates
		LocalDate startDate = LocalDate.parse(tourDetailsDto.getStartDate());
		LocalDate endDate = LocalDate.parse(tourDetailsDto.getEndDate());
		List<String> tourDates = GenerateDate.generateDatesBetween(startDate, endDate);

//		getting List of PlaceIds
		List<Integer> placeIds = placeClients.getListOfPlaceIds(tourDetailsDto.getPlaceIds()).getBody();

//		tourDatesPlaces Entity
		for (int i = 0; i < tourDates.size(); i++) {
			String tourDate = tourDates.get(i);
			Integer selectedPlaceId = placeIds.get(i);

//			create TourDatesPlaces entity
			TourDatesPlaces tourDatesPlaces = new TourDatesPlaces();
			tourDatesPlaces.setTourId(tourDetails.getTourId());
			tourDatesPlaces.setPlaceId(selectedPlaceId);
			tourDatesPlaces.setTourDate(tourDate);
			DatesPlaceRepo.save(tourDatesPlaces);
		}

		return new ResponseEntity<>("Created", HttpStatus.CREATED);
	}

}
