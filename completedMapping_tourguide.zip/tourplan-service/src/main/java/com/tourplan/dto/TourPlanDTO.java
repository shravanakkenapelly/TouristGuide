package com.tourplan.dto;

import java.util.Date;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class TourPlanDTO {

	private Date startDate;
	private Date endDate;

}
