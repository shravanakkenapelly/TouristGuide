package com.tourplan.dto;

import java.util.Date;
import java.util.Map;

import lombok.Data;

@Data
public class HelperDTO {
	
	UserDTO userDto;
	Map<Integer, Date>map;
	
}
