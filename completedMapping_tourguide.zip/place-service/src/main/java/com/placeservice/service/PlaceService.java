package com.placeservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.http.ResponseEntity;

import com.placeservice.dto.PlaceDTO;

public interface PlaceService {

	public ResponseEntity<String> addPlace(PlaceDTO placeDto);

	public ResponseEntity<List<PlaceDTO>> getAllPlaces();

	public ResponseEntity<String> updatePlaces(String name, PlaceDTO placeDto);

	public ResponseEntity<PlaceDTO> getPlaceById(Integer id) throws Throwable;

	public ResponseEntity<PlaceDTO> getPlaceByName(String name);

	public ResponseEntity<String> deletePlace(String name);

	public ResponseEntity<PlaceDTO> getPlaceByTags(String tags);

	public Integer getPlacefortour(Integer placeId);

	public ResponseEntity<List<PlaceDTO>> getListOfPlaceDTOByPlaceId(List<Integer> placeIds);

	public ResponseEntity<List<Integer>> getListOfPlaceIdsl(List<Integer> placeIds);

}
