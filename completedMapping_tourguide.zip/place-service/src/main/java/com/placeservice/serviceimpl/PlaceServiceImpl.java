package com.placeservice.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.placeservice.advices.UserNotFoundException;
import com.placeservice.dto.PlaceDTO;
import com.placeservice.entity.Place;
import com.placeservice.repository.PlaceRepository;
import com.placeservice.service.PlaceService;

@Service
public class PlaceServiceImpl implements PlaceService {

	@Autowired
	private PlaceRepository placerepository;

	@Override
	public ResponseEntity<String> addPlace(PlaceDTO placeDto) {
		Place place = new Place();
		place.setPlaceName(placeDto.getPlaceName());
		place.setImages(placeDto.getImages());
		place.setAddress(placeDto.getAddress());
		place.setArea(placeDto.getArea());
		place.setDistance(placeDto.getDistance());
		place.setDescription(placeDto.getDescription());
		place.setTags(placeDto.getTags());
		placerepository.save(place);
		return new ResponseEntity<>("Places added succesfully", HttpStatus.CREATED);
	}

	@Override
	public ResponseEntity<List<PlaceDTO>> getAllPlaces() {
		List<PlaceDTO> listDtoplace = new ArrayList<>();
		List<Place> listEntity = placerepository.findAll();
		for (Place place : listEntity) {
			PlaceDTO placeDTO = new PlaceDTO();
			placeDTO.setPlaceId(place.getPlaceId());
			placeDTO.setPlaceName(place.getPlaceName());
			placeDTO.setImages(place.getImages());
			placeDTO.setAddress(place.getAddress());
			placeDTO.setArea(place.getArea());
			placeDTO.setDistance(place.getDistance());
			placeDTO.setDescription(place.getDescription());
			placeDTO.setTags(place.getTags());
			listDtoplace.add(placeDTO);
		}
		return new ResponseEntity<>(listDtoplace, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<String> updatePlaces(String placeName, PlaceDTO placeDto) {
		try {
			Place place = placerepository.findByPlaceName(placeName);
			place.setPlaceId(placeDto.getPlaceId());
			place.setPlaceName(placeDto.getPlaceName());
			place.setImages(placeDto.getImages());
			place.setAddress(placeDto.getAddress());
			place.setArea(placeDto.getArea());
			place.setDistance(placeDto.getDistance());
			place.setDescription(placeDto.getDescription());
			place.setTags(placeDto.getTags());
			placerepository.save(place);
			return new ResponseEntity<>("Details Updated Successfully", HttpStatus.OK);
		} catch (Exception e) {
			e.getStackTrace();
		}
		return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<PlaceDTO> getPlaceById(Integer placeId) throws Throwable {
		PlaceDTO placeDTO = new PlaceDTO();

		Place place = placerepository.findById(placeId)
				.orElseThrow(() -> new UserNotFoundException("Place not found with id: " + placeId));

		placeDTO.setPlaceId(place.getPlaceId());
		placeDTO.setPlaceName(place.getPlaceName());
		placeDTO.setImages(place.getImages());
		placeDTO.setAddress(place.getAddress());
		placeDTO.setArea(place.getArea());
		placeDTO.setDistance(place.getDistance());
		placeDTO.setDescription(place.getDescription());
		placeDTO.setTags(place.getTags());
		return new ResponseEntity<>(placeDTO, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<PlaceDTO> getPlaceByName(String name) {
		Place place;
		PlaceDTO placeDTO;
		try {
			place = placerepository.findByPlaceName(name);
			if (place != null) {
				placeDTO = new PlaceDTO();
				placeDTO.setPlaceId(place.getPlaceId());
				placeDTO.setPlaceName(place.getPlaceName());
				placeDTO.setImages(place.getImages());
				placeDTO.setAddress(place.getAddress());
				placeDTO.setArea(place.getArea());
				placeDTO.setDistance(place.getDistance());
				placeDTO.setDescription(place.getDescription());
				placeDTO.setTags(place.getTags());
				return new ResponseEntity<>(placeDTO, HttpStatus.OK);
			}
		} catch (Exception e) {
			e.getStackTrace();
		}
		return new ResponseEntity<>(new PlaceDTO(), HttpStatus.NOT_FOUND);

	}

	@Override
	public ResponseEntity<String> deletePlace(String name) {
		try {
			Place place = placerepository.findByPlaceName(name);
			placerepository.delete(place);
			return new ResponseEntity<>("Place Deleted", HttpStatus.OK);
		} catch (Exception e) {
			e.getStackTrace();
		}
		return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<PlaceDTO> getPlaceByTags(String tags) {
		Place place;
		PlaceDTO placeDTO;
		try {
			place = placerepository.findByTags(tags);
			if (place != null) {
				placeDTO = new PlaceDTO();
				placeDTO.setPlaceId(place.getPlaceId());
				placeDTO.setPlaceName(place.getPlaceName());
				placeDTO.setImages(place.getImages());
				placeDTO.setAddress(place.getAddress());
				placeDTO.setArea(place.getArea());
				placeDTO.setDistance(place.getDistance());
				placeDTO.setDescription(place.getDescription());
				placeDTO.setTags(place.getTags());
				return new ResponseEntity<>(placeDTO, HttpStatus.OK);
			}
		} catch (Exception e) {
			e.getStackTrace();
		}
		return new ResponseEntity<>(new PlaceDTO(), HttpStatus.NOT_FOUND);
	}

	@Override
	public Integer getPlacefortour(Integer placeId) {
		Place placeId1 = placerepository.findById(placeId).get();
		Integer placeId2 = placeId1.getPlaceId();
		return placeId2;
	}

	@Override
	public ResponseEntity<List<PlaceDTO>> getListOfPlaceDTOByPlaceId(List<Integer> placeIds) {

		List<Place> place = new ArrayList<>();
		List<PlaceDTO> placeDTOs = new ArrayList<>();
		
//		getting place for each integer i from db
		for (Integer i : placeIds) {
			place.add(placerepository.findById(i).get());
		}

		for (Place place1 : place) {
			PlaceDTO placeDTO = new PlaceDTO();
			placeDTO.setPlaceId(place1.getPlaceId());
			placeDTO.setPlaceName(place1.getPlaceName());
			placeDTO.setImages(place1.getImages());
			placeDTO.setAddress(place1.getAddress());
			placeDTO.setArea(place1.getArea());
			placeDTO.setDistance(place1.getDistance());
			placeDTO.setDescription(place1.getDescription());
			placeDTO.setTags(place1.getTags());
			placeDTOs.add(placeDTO);
		}
		return new ResponseEntity<>(placeDTOs, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<Integer>> getListOfPlaceIdsl(List<Integer> placeIds) {

		List<Integer> placesId = new ArrayList<>();

		for (Integer i : placeIds) {
			Place place = placerepository.findById(i).get();
			placesId.add(place.getPlaceId());
		}
		return new ResponseEntity<>(placesId, HttpStatus.OK);
	}

}
