package com.serverregistery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerRegisteryApplicationTests {

	@Test
	void contextLoads() {
	}

}
